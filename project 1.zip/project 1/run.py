
from flask import Flask
import psycopg2 as psycopg2
import json
import app as app


app = Flask(__name__)


@app.route('/')
def homepage():
    return 'hey this is my first project '


@app.route("/fetchall")
def fetch_all():
    cursor.execute("select * from public.zipcodes")
    result = cursor.fetchall()
    return str(result)


@app.route('/fetchOne/<zip_id>')
def get_zipcode(zip_id):
    zip_id = str(zip_id);
    command = 'SELECT * FROM public.zipcodes WHERE zip_code = ''' + zip_id + ''
    cursor.execute(command)
    data = cursor.fetchall()
    return str(data)


@app.route('/fetchClosest/<latitude>/<longitude>')
def find_closest(latitude, longitude):
    latitude = str(latitude);
    longitude = str(longitude);
    distance_query = 'SQRT(POW((69.1 * (public.zipcodes.latitude - '+latitude+')) , 2 ) + POW((53 * (public.zipcodes.longitude - '+ longitude +')), 2)) AS distance'
    cursor.execute('SELECT  *,' + distance_query + '  FROM public.zipcodes ORDER BY distance ASC')
    data = cursor.fetchone()
    return str(data)


conn = psycopg2.connect(database="postgres", user='postgres', password='123')
cursor = conn.cursor()

if __name__ == '__main__':
    app.run(debug=True, port='8089')